
const firebaseConfig = {
    apiKey: "AIzaSyATEKeooUjX8YLL9xZK2mP2Bnt8ZGBZ00c",
    authDomain: "project-97-35b62.firebaseapp.com",
    databaseURL: "https://project-97-35b62-default-rtdb.firebaseio.com",
    projectId: "project-97-35b62",
    storageBucket: "project-97-35b62.appspot.com",
    messagingSenderId: "523141493845",
    appId: "1:523141493845:web:f634a2814845edf038d0dc"
  };
  firebase.initializeApp(firebaseConfig);
  function nextpage(){
    window.location = "index2.html" 
}