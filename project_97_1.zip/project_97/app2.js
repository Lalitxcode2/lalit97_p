 
 const firebaseConfig = {
   apiKey: "AIzaSyATEKeooUjX8YLL9xZK2mP2Bnt8ZGBZ00c",
   authDomain: "project-97-35b62.firebaseapp.com",
   databaseURL: "https://project-97-35b62-default-rtdb.firebaseio.com",
   projectId: "project-97-35b62",
   storageBucket: "project-97-35b62.appspot.com",
   messagingSenderId: "523141493845",
   appId: "1:523141493845:web:f634a2814845edf038d0dc"
 };
 firebase.initializeApp(firebaseConfig);
 
 function toy_one(){
    window.location= "index3.html";
    document.getElementById("total_cost").innerHTML = " Rs 1299";  
 }

function toy_two(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 1599";
}

function toy_three(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 2999";
}

function toy_four(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 650";
}

function toy_five(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 50";
}

function toy_six(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 599";
}

function toy_seven(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 30";
}

function toy_eight(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 70";
}

function toy_nine(){
   window.location= "index3.html";
   document.getElementById("total_cost").innerHTML = " Rs 50";
}